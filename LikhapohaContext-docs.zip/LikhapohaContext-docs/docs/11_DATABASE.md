# Database

_Last updated: 2026-06-28_

## Key Tables

### Authentication & Profiles
| Table | Purpose |
|---|---|
| `auth.users` | Supabase auth users |
| `profiles` | User profiles (student, parent, teacher, admin) |
| `families` | Family groupings |

### Learning
| Table | Key Columns | Notes |
|---|---|---|
| `student_progress` | `username, subject, chapter, completed, current_step_index` | Only progress table — chapter_progress does NOT exist |
| `test_history` | `username, percentage (0-100), raw_score, max_score, subject, chapter` | Use `percentage` only — `score` does NOT exist |
| `weak_area_alerts` | `username, subject, chapter, best_score` | |
| `ai_usage_logs` | `username, feature, created_at, total_tokens` | Use for activity, NOT ai_conversation_logs |
| `lesson_cache` | `grade, subject, chapter, step_title, lesson_content, practice_questions` | Pre-generated lessons |

### Student Features
| Table | Purpose |
|---|---|
| `student_exam_schedule` | Student exam dates (added by student or parent) |
| `formula_sheets` | Formula reference content (Grade 5–12, freemium) |

### formula_sheets Columns (v1 base)
`id, grade, subject, chapter, section_title, formula_name, expression, explanation, example, display_order, active, created_at`

### formula_sheets Columns (v2 — applied)
`topic, variables, solution_steps, memory_tip, tags (TEXT[]), difficulty, chapter_order`

### formula_sheets Columns (v3 — PENDING Supabase Studio application)
`expression_latex, variables_json (JSONB), use_when, mcqs_json (JSONB), source_type, status, quality_score, updated_at`

**When v3 not applied:** endpoint falls back to base columns automatically (42703 error caught).

### Parent Platform
| Table | Purpose |
|---|---|
| `parent_notifications` | Persistent notifications |

### Admin / QA
| Table | Purpose |
|---|---|
| `lesson_quality_audit_runs` | Lesson quality audit job history |
| `platform_audit_logs` | Admin audit trail (never expose to parents/students) |

### Teacher Platform
| Table | Purpose |
|---|---|
| `teacher_student_assignments` | Teacher-student relationships |
| `teacher_classrooms` | Classroom groupings |

### Payments
| Table | Purpose |
|---|---|
| `payments` | Payment records |
| `subscription_timeline` | History |
| `offer_redemptions` | Offer code usage |

## Tables That Do NOT Exist

| Table | Status | Use Instead |
|---|---|---|
| `chapter_progress` | ❌ DOES NOT EXIST | `student_progress` |
| `lesson_progress` | ❌ DOES NOT EXIST | `student_progress` |
| `homework` | ❌ Not yet created | Return `available: false` |
| `exam_schedule` (standalone) | ❌ Use `student_exam_schedule` | `student_exam_schedule` |
| `ai_conversation_logs` | ❌ DOES NOT EXIST | `ai_usage_logs` |
| `student_activity` | ❌ DOES NOT EXIST | `ai_usage_logs` |

## Column Notes

### test_history
- **`percentage`** ← USE THIS (already 0-100)
- `raw_score` — marks obtained
- `max_score` — total marks
- `score` ← **DOES NOT EXIST**
- `total_questions` ← **DOES NOT EXIST**
- Always use `_normalize_score_pct(percentage, raw_score, max_score)`

### profiles
- `access_cbse` — canonical paid access flag
- `subscription_expires_at` — nullable
- `subscription_plan` — string, use canonical resolver not this directly
- `parent_id` — nullable, set when parent creates child
- `family_id` — nullable

## Migrations

All in `backend/migrations/`, idempotent:

| File | Purpose |
|---|---|
| `20260628_formula_sheets.sql` | formula_sheets base table |
| `20260628_formula_sheets_v2.sql` | topic, variables, solution_steps, memory_tip, difficulty, chapter_order |
| `20260628_formula_sheets_v3.sql` | expression_latex, mcqs_json, source_type, status (PENDING application) |
| `20260628_student_exam_schedule.sql` | student_exam_schedule table |
| `20260628_lesson_quality_audit_runs.sql` | QA audit job history |
| `20260627_parent_notifications.sql` | parent_notifications table |

## Safety Rules

1. Never expose `platform_audit_logs` to parents or students
2. Never expose teacher-private fields to parents
3. Missing tables: use `_safe_query()` — never crash
4. Student data: `require_student` dependency
5. Parent data: `require_parent` + `_verify_child_ownership()`
6. Admin QA data: `require_admin` — all `/api/admin/qa/*` endpoints
